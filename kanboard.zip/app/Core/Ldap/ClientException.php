<?php

namespace Kanboard\Core\Ldap;

use Exception;

/**
 * LDAP Client Exception
 *
 * @package ldap
 * @author  Frederic Guillot
 */
class ClientException extends Exception
{
}
